import React, { useEffect, useState } from "react";
import {
  Grid,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import { TVChartContainer } from "./common/TVChartContainer";
import Table from "./Table";
import TokenDetailsPanel from "./TokenDetailsPanel";
import { useSelector } from "react-redux";
import "./style.css";

const MainComponent = ({ selectedToken, onSelectToken }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(true);
  const theme = useTheme();
  const isLargeScreen = useMediaQuery(theme.breakpoints.up("md"));
  const tokenList = useSelector((state) => state.tokenReducer.tokenList);

  useEffect(() => {
    if (!selectedToken && tokenList.length) {
      onSelectToken(tokenList[0]);
    }
  }, [selectedToken, tokenList, onSelectToken]);

  return (
    <Grid
      container
      spacing={0}
      sx={{
        backgroundColor: "#191919",
        paddingRight: isLargeScreen ? "7vw" : 0,
      }}
    >
      <Grid
        item
        xs={12}
        md={isMenuOpen ? 9 : 12}
        sx={{ transition: "width 0.5s", position: "relative" }}
      >
        <TVChartContainer height={isMenuOpen ? 70 : 70} />
        <Table height={isMenuOpen ? 70 : 90} />
        {isLargeScreen && (
          <button
            className="menubutton"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Hide token details" : "Show token details"}
          >
            <div style={{ marginTop: "-35%" }}>{isMenuOpen ? "›" : "‹"}</div>
          </button>
        )}
      </Grid>

      {isMenuOpen && (
        <Grid item xs={12} md={3} className="font-header">
          <TokenDetailsPanel
            tokenList={tokenList}
            selectedToken={selectedToken}
            onSelectToken={onSelectToken}
          />
        </Grid>
      )}
    </Grid>
  );
};

export default MainComponent;
