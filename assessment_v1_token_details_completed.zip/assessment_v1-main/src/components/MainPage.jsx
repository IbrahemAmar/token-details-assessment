import React, { useState } from "react";
import MainComponent from "./MainComponent";
import { Header } from "./Header";
import { TokenList } from "./TokenList";
import Footer from "./Footer";

const MainPage = () => {
  const [selectedToken, setSelectedToken] = useState(null);

  return (
    <div>
      <Header />
      <TokenList onSelectToken={setSelectedToken} />
      <MainComponent
        selectedToken={selectedToken}
        onSelectToken={setSelectedToken}
      />
      <Footer />
    </div>
  );
};

export default MainPage;
