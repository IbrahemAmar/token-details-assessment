import React, { useMemo } from "react";
import { formatNumber, formatTimeDifference, removeW } from "../utils/funcs";
import { svg2img } from "../utils/randomAvatar";
import { useSelector } from "react-redux";
import "./tokenDetails.css";

const TokenDetailsPanel = ({ tokenList, selectedToken, onSelectToken }) => {
  const swapTransactions = useSelector(
    (state) => state.swapTransactionReducer.swapTransactionList
  );

  const tokenTransactions = useMemo(() => {
    if (!selectedToken || !swapTransactions?.length) return [];

    const symbol = selectedToken.symbol?.toLowerCase();
    const id = selectedToken.id?.toLowerCase();

    return swapTransactions
      .filter((transaction) => {
        const symbol0 = transaction.symbol0?.toLowerCase();
        const symbol1 = transaction.symbol1?.toLowerCase();
        return (
          symbol0 === symbol ||
          symbol1 === symbol ||
          transaction.token0?.id?.toLowerCase() === id ||
          transaction.token1?.id?.toLowerCase() === id
        );
      })
      .filter((transaction) => transaction.type === "Swap")
      .slice(0, 5);
  }, [selectedToken, swapTransactions]);

  if (!selectedToken) {
    return (
      <aside className="token-details-panel empty-panel">
        <div className="details-empty-icon">◎</div>
        <h2>Select a token</h2>
        <p>Click a token name to view its market data, liquidity, activity and contract information.</p>
      </aside>
    );
  }

  const price = Number(selectedToken.derivedUSD || 0);
  const volume24h = Number(selectedToken.volume24HrsUSD || 0);
  const marketCap = Number(selectedToken.tradeVolumeUSD || 0);
  const liquidity = Number(selectedToken.totalLiquidityUSD || 0);
  const change = selectedToken.tradeVolumeETH
    ? (Number(selectedToken.volume24HrsETH || 0) / Number(selectedToken.tradeVolumeETH)) * 100
    : 0;

  const logo = selectedToken.logo
    ? `https://assets.thetatoken.org/tokens/${selectedToken.logo}`
    : svg2img(selectedToken);

  return (
    <aside className="token-details-panel font-header">
      <div className="details-panel-header">
        <div>
          <span className="details-eyebrow">TOKEN DETAILS</span>
          <h2>Market Overview</h2>
        </div>
        <span className="details-live">LIVE</span>
      </div>

      <div className="token-picker">
        <span className="picker-label">Select token</span>
        <div className="picker-list">
          {tokenList.slice(0, 8).map((token) => {
            const active = token.id === selectedToken.id;
            return (
              <button
                type="button"
                key={token.id}
                className={`picker-token ${active ? "active" : ""}`}
                onClick={() => onSelectToken(token)}
              >
                <span>{removeW(token.symbol || "")}</span>
                <span className="picker-arrow">›</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="selected-token">
        <img src={logo} alt={`${selectedToken.symbol} logo`} />
        <div>
          <div className="selected-token-symbol">{removeW(selectedToken.symbol || "TOKEN")}</div>
          <div className="selected-token-name">{selectedToken.name || "Unnamed token"}</div>
        </div>
      </div>

      <div className="price-block">
        <span>Current price</span>
        <strong>${price.toLocaleString(undefined, { maximumFractionDigits: 8 })}</strong>
        <em className={change >= 0 ? "positive" : "negative"}>
          {change >= 0 ? "+" : ""}{change.toFixed(2)}% volume ratio
        </em>
      </div>

      <div className="metric-grid">
        <div><span>Market Cap</span><strong>${formatNumber(marketCap)}</strong></div>
        <div><span>Liquidity</span><strong>${formatNumber(liquidity)}</strong></div>
        <div><span>24h Volume</span><strong>${formatNumber(volume24h)}</strong></div>
        <div><span>Transactions</span><strong>{Number(selectedToken.txCount || 0).toLocaleString()}</strong></div>
      </div>

      <div className="detail-section">
        <div className="section-title">Contract &amp; token data</div>
        <div className="detail-row"><span>Symbol</span><strong>{selectedToken.symbol || "—"}</strong></div>
        <div className="detail-row"><span>Contract</span><strong title={selectedToken.id}>{selectedToken.id || "—"}</strong></div>
        <div className="detail-row"><span>Derived ETH</span><strong>{Number(selectedToken.derivedETH || 0).toFixed(8)}</strong></div>
        <div className="detail-row"><span>Start date</span><strong>{selectedToken.start_date || selectedToken.date || "—"}</strong></div>
      </div>

      <div className="detail-section">
        <div className="section-title">Recent token activity</div>
        {tokenTransactions.length ? (
          <div className="activity-list">
            {tokenTransactions.map((transaction, index) => (
              <div className="activity-row" key={transaction.id || index}>
                <div>
                  <strong>{transaction.symbol0 || "Token"} → {transaction.symbol1 || "Token"}</strong>
                  <span>{formatTimeDifference(Number(transaction.timestamp || 0)) || "recent"}</span>
                </div>
                <span className={Number(transaction.amount0In || 0) ? "positive" : "negative"}>
                  {Number(transaction.amount0In || 0) ? "BUY" : "SELL"}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="muted-text">No matching swap activity is available in the loaded transaction feed.</p>
        )}
      </div>
    </aside>
  );
};

export default TokenDetailsPanel;
